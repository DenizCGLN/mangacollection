<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;
if ($id) {
    $stmt = $conn->prepare("DELETE FROM mangas WHERE id = ?");
    $stmt->execute([$id]);
}

header('Location: index.php');
exit;
?>
