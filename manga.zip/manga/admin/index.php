<?php
session_start();
require '../db.php';

// Admin girişi kontrolü
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Tüm mangaları çek
$stmt = $conn->query("SELECT * FROM mangas");
$mangas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<header>
    <h1>Admin Paneli</h1>
</header>
<div class="container">
    <a href="add.php" style="margin-bottom: 20px; display: inline-block;">+ Yeni Manga Ekle</a> 
    <a href="logout.php" style="margin-bottom: 20px; display: inline-block; color: red;">Çıkış Yap</a>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: center; border-collapse: collapse;">
        <tr style="background-color: #007bff; color: white;">
            <th>Kapak Resmi</th>
            <th>ID</th>
            <th>Ad</th>
            <th>Yazar</th>
            <th>Tür</th>
            <th>Durum</th>
            <th>İşlemler</th>
        </tr>
        <?php foreach ($mangas as $manga): ?>
        <tr>
            <td>
                <img src="../assets/images/<?= htmlspecialchars($manga['cover_image']) ?>" alt="<?= htmlspecialchars($manga['name']) ?>" width="100">
            </td>
            <td><?= htmlspecialchars($manga['id']) ?></td>
            <td><?= htmlspecialchars($manga['name']) ?></td>
            <td><?= htmlspecialchars($manga['author']) ?></td>
            <td><?= htmlspecialchars($manga['genre']) ?></td>
            <td><?= htmlspecialchars($manga['status']) ?></td>
            <td>
                <a href="edit.php?id=<?= $manga['id'] ?>" style="color: green;">Düzenle</a> |
                <a href="delete.php?id=<?= $manga['id'] ?>" style="color: red;" onclick="return confirm('Bu mangayı silmek istediğinize emin misiniz?')">Sil</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
