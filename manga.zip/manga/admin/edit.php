<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

$id = $_GET['id'] ?? null;
if (!$id) {
    die("Geçersiz istek! Manga ID'si gerekli.");
}

$stmt = $conn->prepare("SELECT * FROM mangas WHERE id = ?");
$stmt->execute([$id]);
$manga = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$manga) {
    die("Manga bulunamadı.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $status = $_POST['status'];
    $description = $_POST['description'];
    $published_volumes = $_POST['published_volumes'];
    $collected_volumes = $_POST['collected_volumes'];
    $read_volumes = $_POST['read_volumes'];
    $cover_image = $manga['cover_image'];

    if (!empty($_FILES['cover_image']['name'])) {
        $target_dir = "../assets/images/";
        $cover_image = basename($_FILES['cover_image']['name']);
        $target_file = $target_dir . $cover_image;

        if (!move_uploaded_file($_FILES['cover_image']['tmp_name'], $target_file)) {
            $error = "Kapak resmi yüklenirken bir hata oluştu!";
        }
    }

    $stmt = $conn->prepare("UPDATE mangas SET name = ?, author = ?, genre = ?, status = ?, description = ?, published_volumes = ?, collected_volumes = ?, read_volumes = ?, cover_image = ? WHERE id = ?");
    $stmt->execute([$name, $author, $genre, $status, $description, $published_volumes, $collected_volumes, $read_volumes, $cover_image, $id]);

    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Manga Düzenle</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<header>
    <h1>Manga Düzenle</h1>
</header>
<div class="container">
    <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
    <form method="POST" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 10px;">
        <label>Ad:</label>
        <input type="text" name="name" value="<?= htmlspecialchars($manga['name']) ?>" required>
        <label>Yazar:</label>
        <input type="text" name="author" value="<?= htmlspecialchars($manga['author']) ?>">
        <label>Tür:</label>
        <input type="text" name="genre" value="<?= htmlspecialchars($manga['genre']) ?>">
        <label>Durum:</label>
        <select name="status">
            <option value="Okunuyor" <?= $manga['status'] === 'Okunuyor' ? 'selected' : '' ?>>Okunuyor</option>
            <option value="Tamamlandı" <?= $manga['status'] === 'Tamamlandı' ? 'selected' : '' ?>>Tamamlandı</option>
            <option value="Planlanıyor" <?= $manga['status'] === 'Planlanıyor' ? 'selected' : '' ?>>Planlanıyor</option>
        </select>
        <label>Açıklama:</label>
        <textarea name="description" rows="5"><?= htmlspecialchars($manga['description']) ?></textarea>
        <label>Yayınlanan Ciltler:</label>
        <input type="number" name="published_volumes" value="<?= htmlspecialchars($manga['published_volumes']) ?>" min="0">
        <label>Toplanan Ciltler:</label>
        <input type="number" name="collected_volumes" value="<?= htmlspecialchars($manga['collected_volumes']) ?>" min="0">
        <label>Okunan Ciltler:</label>
        <input type="number" name="read_volumes" value="<?= htmlspecialchars($manga['read_volumes']) ?>" min="0">
        <label>Kapak Resmi (Mevcut Resim: <?= htmlspecialchars($manga['cover_image']) ?>):</label>
        <input type="file" name="cover_image">
        <button type="submit" style="background-color: #007bff; color: white; padding: 10px; border: none; border-radius: 5px;">Güncelle</button>
    </form>
</div>
</body>
</html>
