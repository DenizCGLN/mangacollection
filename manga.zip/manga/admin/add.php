<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $author = $_POST['author'];
    $genre = $_POST['genre'];
    $status = $_POST['status'];
    $description = $_POST['description'];
    $cover_image = 'default.jpg'; // Varsayılan kapak resmi

    if (!empty($_FILES['cover_image']['name'])) {
        $target_dir = "../assets/images/";
        $cover_image = basename($_FILES['cover_image']['name']);
        $target_file = $target_dir . $cover_image;

        if (!move_uploaded_file($_FILES['cover_image']['tmp_name'], $target_file)) {
            $error = "Kapak resmi yüklenirken bir hata oluştu!";
        }
    }

    $stmt = $conn->prepare("INSERT INTO mangas (name, author, genre, status, description, cover_image) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([$name, $author, $genre, $status, $description, $cover_image]);

    header('Location: index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Manga Ekle</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<header>
    <h1>Yeni Manga Ekle</h1>
</header>
<div class="container">
    <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
    <form method="POST" enctype="multipart/form-data" style="display: flex; flex-direction: column; gap: 10px;">
        <label>Ad:</label>
        <input type="text" name="name" required>
        <label>Yazar:</label>
        <input type="text" name="author">
        <label>Tür:</label>
        <input type="text" name="genre">
        <label>Durum:</label>
        <select name="status">
            <option value="Okunuyor">Okunuyor</option>
            <option value="Tamamlandı">Tamamlandı</option>
            <option value="Planlanıyor">Planlanıyor</option>
        </select>
        <label>Açıklama:</label>
        <textarea name="description" rows="5"></textarea>
        <label>Kapak Resmi:</label>
        <input type="file" name="cover_image">
        <button type="submit" style="background-color: #007bff; color: white; padding: 10px; border: none; border-radius: 5px;">Kaydet</button>
    </form>
</div>
</body>
</html>
