<?php
session_start();
require '../db.php';

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Mangaları gruplandırmak için veritabanı sorgusu
$stmt = $conn->query("
    SELECT genre, status, COUNT(*) as count
    FROM mangas
    GROUP BY genre, status
    ORDER BY genre, status
");
$statistics = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İstatistikler</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<header>
    <h1>İstatistikler</h1>
</header>
<div class="container">
    <h2>Mangaların Tür ve Durumlarına Göre Dağılımı</h2>
    <table border="1" cellpadding="10" cellspacing="0" style="width: 100%; text-align: center; border-collapse: collapse;">
        <tr style="background-color: #007bff; color: white;">
            <th>Tür</th>
            <th>Durum</th>
            <th>Toplam</th>
        </tr>
        <?php foreach ($statistics as $stat): ?>
        <tr>
            <td><?= htmlspecialchars($stat['genre']) ?></td>
            <td><?= htmlspecialchars($stat['status']) ?></td>
            <td><?= htmlspecialchars($stat['count']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <a href="index.php" style="margin-top: 20px; display: inline-block; color: #007bff;">Admin Paneline Geri Dön</a>
</div>
</body>
</html>
