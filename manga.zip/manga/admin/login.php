<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sabit admin kullanıcı bilgileri
    $admin_user = 'admin';
    $admin_pass = '123';

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Kullanıcı adı ve şifre doğrulama
    if ($username === $admin_user && $password === $admin_pass) {
        $_SESSION['admin_logged_in'] = true; // Oturum oluştur
        header('Location: index.php'); // Yönetim paneline yönlendir
        exit;
    } else {
        $error = "Geçersiz kullanıcı adı veya şifre!";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Admin Girişi</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
<header>
    <h1>Admin Paneli Giriş</h1>
</header>
<div class="container">
    <?php if (!empty($error)) echo "<p style='color: red;'>$error</p>"; ?>
    <form method="POST">
        <label>Kullanıcı Adı:</label>
        <input type="text" name="username" required>
        <br>
        <label>Şifre:</label>
        <input type="password" name="password" required>
        <br>
        <button type="submit">Giriş Yap</button>
    </form>
</div>
</body>
</html>
